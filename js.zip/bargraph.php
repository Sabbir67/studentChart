
<!DOCTYPE html>
<html>
<head>
	<title>ChartJs_Bargraph</title>
	<style type="text/css">
		#chart-container{
			width: 640px;
			height: auto;
		}

	</style>
</head>
<body>
	<button onclick="ddta()">Show chart</button>
	
<div id="chart-container">
	<canvas id="mycanvas"></canvas>
</div>
<div id="chart-container">
	<canvas id="mycanvas2"></canvas>
</div>

<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="js/Chart.min.js"></script>
<script type="text/javascript" src="js/app.js"></script>
<script type="text/javascript" src="js/test.js"></script>
</body>
</html>