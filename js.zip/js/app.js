function ddta(){
$(document).ready(function(){
	$.ajax({
		url: "http://localhost/Chart/data.php",
		method: "GET",
		success:function(data){
			console.log(data);
			var player =[];
			var score = [];
			console.log(data[1]);

			for(var i in data){
				player.push(""+data[i].major);
				score.push(data[i].year);
			}

			var chartdata = {
				labels: player,
				datasets: [{
            	label: "My First dataset",
           		 backgroundColor: 'rgb(255, 99, 132)',
            	borderColor: 'rgb(255, 99, 132)',
            	data: score
				}
			]
		};

			var ctx = $("#mycanvas");
			var barGraph = new Chart(ctx,{
				type : 'bar',
				data:chartdata
			});

		},
		error: function(data){
			console.log(data);
		}
	});
});
}
//=============================


