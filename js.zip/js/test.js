function ddta2(){
$(document).ready(function(){
	$.ajax({
		url: "http://localhost/Chart/data.php",
		method: "GET",
		success:function(data2){
			console.log(data2);
			var player =[];
			var score = [];
			console.log(data2[1]);

			for(var i in data2){
				player.push(""+data2[i].university);
				score.push(data2[i].year);
			}

			var chartdata = {
				labels: player,
				datasets: [{
            	label: "My First dataset",
           		 backgroundColor: 'rgb(255, 99, 132)',
            	borderColor: 'rgb(255, 99, 132)',
            	data2: score
				}
			]
		};

			var ctx = $("#mycanvas2");
			var barGraph = new Chart(ctx,{
				type : 'bar',
				data2:chartdata
			});

		},
		error: function(data2){
			console.log(data2);
		}
	});
});
}
