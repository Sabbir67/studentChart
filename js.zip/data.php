<?php 
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sms";

$conn = mysqli_connect($servername, $username, $password, $dbname);

//$sql = "SELECT playerId,score FROM ctable2";
//$sql = "SELECT major,year FROM studentt";
$sql = "SELECT year,Count(*) FROM studentt GROUP BY year";
//$sql2 = "SELECT university,year FROM studentt";




$result = $conn -> query($sql) or die();

$data = array();

foreach ($result as $row) {
	$data[] = $row;
}

$result->close();
$conn->close();

echo json_encode($data);

 ?>